import {ApolloServer} from "@apollo/server";
import {startStandaloneServer} from "@apollo/server/standalone";
import {resolvers} from "./resolvers.ts";
import {FlightModel} from "./types.ts";
import {schema} from "./schema.ts";
import {MongoClient} from "mongodb";


const MONGO_URL = Deno.env.get("MONGO_URL");
if (!MONGO_URL) throw new Error("MONGO_URL is not defined");

const Mclient = new MongoClient(MONGO_URL);
await Mclient.connect();

const db = Mclient.db("VUELOS_AENA");

const flightsCollection = db.collection<FlightModel>("flights");


const server = new ApolloServer({
    typeDefs: schema, resolvers});

const {url} = await startStandaloneServer(server, {
    context: async() => ({flightsCollection})});

console.log(`🚀  Server ready at: ${url}`);