import { Collection,ObjectId } from "mongodb";
import { FlightModel,Flight } from "./types.ts";
import { fromModeltoFlight } from "./utils.ts";

export const resolvers = {
    Query:{
        getFlights: async(
            _: unknown,
            { origin, destination }: { origin?: string, destination?: string },
            context: { flightsCollection: Collection<FlightModel> }
        ): Promise<Flight[]> => {
            const query: Record<string, unknown> = {};
            if (origin) query.origin = origin;
            if (destination) query.destination = destination;
            const flights = await context.flightsCollection.find(query).toArray();
            return flights.map(fromModeltoFlight);
        },
        getFlight: async(
            _:unknown,
            {_id}: {_id:string},
            context :{flightsCollection:Collection<FlightModel>}
        ):Promise<Flight> => {
            const flight = await context.flightsCollection.findOne({_id: new ObjectId(_id)});
            if(!flight) throw new Error("Flight not found");
            return fromModeltoFlight(flight);
        },
    },  
    Mutation: {
        addFlight: async(
            _:unknown,
            args:{origin:string,destination:string,time:string},
            context :{flightsCollection:Collection<FlightModel>},
        ):Promise<Flight> => {
            if (!args.origin || !args.destination || !args.time) throw new Error("Missing required fields");
            const {insertedId} = await context.flightsCollection.insertOne(args);
            const flightModel = await context.flightsCollection.findOne({_id: insertedId});
if (!flightModel) {
    throw new Error("Flight not found");
}
return fromModeltoFlight(flightModel);
    }   
    }
}