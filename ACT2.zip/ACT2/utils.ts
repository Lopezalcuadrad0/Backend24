import { FlightModel, Flight } from "./types.ts";

export const fromModeltoFlight = (flightmodel: FlightModel): Flight => {
    return {
        id: flightmodel._id!.toString(),
        origin: flightmodel.origin,
        destination: flightmodel.destination,
        time: flightmodel.time
    }
    
}
